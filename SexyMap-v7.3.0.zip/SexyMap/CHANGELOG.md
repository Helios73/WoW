# SexyMap

## [v7.3.0](https://github.com/funkydude/SexyMap/tree/v7.3.0) (2017-08-29)
[Full Changelog](https://github.com/funkydude/SexyMap/compare/v7.2.1...v7.3.0)

- drop more buttons  
- bump toc  
